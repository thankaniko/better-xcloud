#!/usr/bin/env python3
from pathlib import Path
import io, json, tarfile, gzip, tempfile, subprocess, hashlib
root=Path(__file__).resolve().parent
app=root/'app'; meta=json.loads((app/'appinfo.json').read_text()); ident,ver=meta['id'],meta['version']
output=root.parent/f'{ident}_{ver}_all.ipk'
def archive(path, entries):
    with path.open('wb') as f, gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as gz, tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as t:
        for name, data in sorted(entries.items()):
            i=tarfile.TarInfo(name); i.size=len(data); i.mode=0o644; i.mtime=0; t.addfile(i,io.BytesIO(data))
with tempfile.TemporaryDirectory() as tmp:
    d=Path(tmp); (d/'debian-binary').write_bytes(b'2.0\n')
    control=f'Package: {ident}\nVersion: {ver}\nSection: misc\nPriority: optional\nArchitecture: all\nwebOS-Package-Format-Version: 2\n'
    archive(d/'control.tar.gz',{'control':control.encode()})
    entries={f'usr/palm/applications/{ident}/{p.relative_to(app).as_posix()}':p.read_bytes() for p in app.rglob('*') if p.is_file()}
    entries[f'usr/palm/packages/{ident}/packageinfo.json']=json.dumps({'id':ident,'version':ver,'app':ident,'services':[]}).encode()
    archive(d/'data.tar.gz',entries)
    output.unlink(missing_ok=True)
    subprocess.run(['ar','rcD',str(output),'debian-binary','control.tar.gz','data.tar.gz'],cwd=d,check=True)
    print(output,output.stat().st_size,hashlib.sha256(output.read_bytes()).hexdigest())
