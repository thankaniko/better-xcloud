'use strict';
const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path');
const code=fs.readFileSync(path.join(__dirname,'../app/webOSUserScripts/userScript.js'),'utf8');
function env(url,mode,codec){
 const attrs={},requests=[],storage={'bx.community.final.mode':mode,'bx.community.final.codec':codec};
 let order=null;const listeners={};
 const caps=[{mimeType:'video/H264'},{mimeType:'video/rtx'},{mimeType:'video/AV1'},{mimeType:'video/VP9'}];
 class PC{constructor(){this.connectionState='new';}getTransceivers(){return[{receiver:{track:{kind:'video'}},setCodecPreferences(list){order=list.map(c=>c.mimeType);}}];}createOffer(){return Promise.resolve('original-offer');}createAnswer(){return Promise.resolve('original-answer');}getStats(){return Promise.resolve(new Map());}}
 function el(tag){return {tagName:tag.toUpperCase(),style:{},children:[],appendChild(x){this.children.push(x);x.parentNode=this;},removeChild(x){this.children=this.children.filter(y=>y!==x);x.parentNode=null;}};}
 const document={documentElement:{setAttribute(k,v){attrs[k]=v;}},body:el('body'),getElementsByTagName(){return[];},createElement:el,addEventListener(k,f){listeners[k]=f;}};
 const nativeFetch=async function(...args){requests.push(new Request(...args));return new Response('{}');};
 const window={location:new URL(url),document,navigator:{userAgent:'Chrome/120.0'},RTCPeerConnection:PC,RTCRtpReceiver:{getCapabilities(){return {codecs:caps};}},Reflect,fetch:nativeFetch,localStorage:{getItem(k){return storage[k]||null;},setItem(k,v){storage[k]=v;}},addEventListener(){},confirm(){return true;}};
 window.top=window.self=window;
 vm.runInNewContext(code,{window,document,navigator:window.navigator,location:window.location,localStorage:window.localStorage,RTCRtpReceiver:window.RTCRtpReceiver,URL,Request,Headers,Response,Promise,Reflect,Proxy,Date,Number,String,Array,JSON,Math,isFinite,setInterval(){},setTimeout});
 return {window,attrs,requests,nativeFetch,order:()=>order};
}
async function main(){
 let x=env('https://login.live.com/', 'hq','efficient');assert.equal(x.window.fetch,x.nativeFetch);assert.equal(x.attrs['data-bx-probe'],undefined);
 x=env('https://play.xbox.com/auth/signin','hq','efficient');assert.equal(x.window.fetch,x.nativeFetch);
 x=env('https://play.xbox.com/','max','efficient');let pc=new x.window.RTCPeerConnection();assert.equal(await pc.createOffer(),'original-offer');assert.equal(x.order()[0],'video/AV1');assert.equal(x.order().length,4);
 x=env('https://play.xbox.com/','native','efficient');pc=new x.window.RTCPeerConnection();assert.equal(await pc.createOffer(),'original-offer');assert.equal(x.order(),null);
 const endpoint='https://brs.core.gssv-play-prod.xboxlive.com/v5/sessions/cloud/play';const init={method:'POST',headers:{'x-ms-device-info':JSON.stringify({dev:{os:{name:'webos',ver:'25'},browser:{browserVersion:'120'}}}),'content-type':'application/json'},body:JSON.stringify({settings:{osName:'webos',locale:'pt-BR'},other:42})};
 x=env('https://play.xbox.com/','hq','auto');await x.window.fetch(endpoint,init);assert.equal(x.requests.length,1);let r=x.requests[0],body=await r.json(),dev=JSON.parse(r.headers.get('x-ms-device-info'));assert.equal(body.settings.osName,'tizen');assert.equal(body.other,42);assert.equal(dev.dev.os.ver,'25');assert.equal(dev.dev.os.name,'tizen');assert.equal(dev.dev.browser.browserVersion,'120');
 await x.window.fetch('https://example.com/v5/sessions/cloud/play',init);assert.equal((await x.requests[1].json()).settings.osName,'webos');
 await x.window.fetch(endpoint,{...init,body:'invalid JSON'});assert.equal(await x.requests[2].text(),'invalid JSON');
 x=env('https://play.xbox.com/','max','auto');await x.window.fetch(endpoint,init);assert.equal((await x.requests[0].json()).settings.osName,'webos');
 console.log('PASS: origin and login guard, codec ordering, native fallback, HQ scope, request preservation, malformed input fallback');
}
main().catch(e=>{console.error(e);process.exitCode=1;});
